import subprocess
import time
import logging

# Set up logging to a file on the Android device
log_path = "/storage/emulated/0/android/media/root/log/log6.txt"
logging.basicConfig(filename=log_path, level=logging.INFO, format='%(asctime)s - %(message)s')

def log(message):
    """Log messages to the file and print them to the console."""
    logging.info(message)
    print(message)

def run_root_command(command):
    """Run a command as root on the Android device."""
    root_command = f"su -c '{command}'"
    log(f"Running root command: {root_command}")
    try:
        result = subprocess.run(root_command, shell=True, check=True, text=True, capture_output=True)
        log(f"Command output: {result.stdout}")
    except subprocess.CalledProcessError as e:
        log(f"Error executing command: {e.stderr}")
        
def is_app_installed(package_name):
    """Check if the app is installed."""
    command = f"pm list packages | grep {package_name}"
    try:
        result = subprocess.run(command, shell=True, check=True, text=True, capture_output=True)
        return bool(result.stdout)
    except subprocess.CalledProcessError:
        return False

def is_app_enabled(package_name):
    """Check if the app is enabled."""
    command = f"pm list packages -e | grep {package_name}"
    try:
        result = subprocess.run(command, shell=True, check=True, text=True, capture_output=True)
        return bool(result.stdout)
    except subprocess.CalledProcessError:
        return False

def is_app_disabled(package_name):
    """Check if the app is disabled."""
    command = f"pm list packages -d | grep {package_name}"
    try:
        result = subprocess.run(command, shell=True, check=True, text=True, capture_output=True)
        return bool(result.stdout)
    except subprocess.CalledProcessError:
        return False

def enable_app(package_name):
    """Enable a disabled app on the device."""
    log(f"Enabling app: {package_name}")
    run_root_command(f"pm enable {package_name}")

def disable_app(package_name):
    """Disable an app on the device."""
    log(f"Disabling app: {package_name}")
    run_root_command(f"pm disable {package_name}")

def uninstall_apk(package_name):
    """Uninstall an APK from the device."""
    log(f"Uninstalling APK: {package_name}")
    run_root_command(f"pm uninstall {package_name}")

def manage_app(package_name):
    """Automatically determine the action for the app."""
    if is_app_installed(package_name):
        log(f"{package_name} is installed.")
        
        # Check if the app is enabled
        if is_app_enabled(package_name):
            log(f"{package_name} is already enabled.")
        elif is_app_disabled(package_name):
            log(f"{package_name} is currently disabled. Enabling it now...")
            enable_app(package_name)

    else:
        log(f"{package_name} is not installed. Installing...")
        # Optionally, install the app if it isn't installed (You can specify the APK path here)
        # install_apk('path_to_apk')

    # Optionally, Uninstall if you want to manage uninstallation logic
    # Uncomment below line to uninstall the app
    # uninstall_apk(package_name)

def main():
    package_name = "com.basic.root.tools"
    manage_app(package_name)

if __name__ == "__main__":
    main()