import os

import json

import requests

import time


class CacheManager:

    def __init__(self, base_path):

        self.base_path = base_path

        self.create_cache_structure()


    def create_cache_structure(self):

        cache_structure = ["images", "api", "temp", "logs"]

        os.makedirs(self.base_path, exist_ok=True)

        for folder in cache_structure:

            path = os.path.join(self.base_path, folder)

            os.makedirs(path, exist_ok=True)

            print(f"Created: {path}")


    def cache_api_response(self, api_name, data):

        cache_file_path = os.path.join(self.base_path, 'api', f'{api_name}.json')

        with open(cache_file_path, 'w') as cache_file:

            json.dump(data, cache_file)

            print(f"Cached response for {api_name} at {cache_file_path}")


    def load_cached_api_response(self, api_name):

        cache_file_path = os.path.join(self.base_path, 'api', f'{api_name}.json')

        if os.path.exists(cache_file_path):

            with open(cache_file_path, 'r') as cache_file:

                data = json.load(cache_file)

                print(f"Loaded cached response for {api_name}: {data}")

                return data

        else:

            print(f"No cached response found for {api_name}.")

            return None


    def cache_image(self, image_url):

        image_name = os.path.basename(image_url)

        image_path = os.path.join(self.base_path, 'images', image_name)

        response = requests.get(image_url)

        if response.status_code == 200:

            with open(image_path, 'wb') as img_file:

                img_file.write(response.content)

                print(f"Cached image at: {image_path}")

        else:

            print(f"Failed to fetch image from {image_url}")


    def clear_old_cache(self, expiration_time):

        current_time = time.time()

        for root, dirs, files in os.walk(self.base_path):

            for file in files:

                file_path = os.path.join(root, file)

                file_age = current_time - os.path.getmtime(file_path)

                if file_age > expiration_time:

                    os.remove(file_path)

                    print(f"Deleted old cache file: {file_path}")