from cache_manager import CacheManager

# Specify the base path for your cache folder
cache_folder = "/storage/emulated/0/Android/media/root/main/Cache.txt"  # Change this to your desired location

# Create an instance of CacheManager
cache_manager = CacheManager(cache_folder)

# Cache an API response
example_data = {'name': 'Alice', 'age': 30}
cache_manager.cache_api_response('user_data', example_data)

# Load cached API response
cache_manager.load_cached_api_response('user_data')

# Cache an image from a local file
local_image_path = "/storage/emulated/0/DCIM/screenshots/Screenshot_20241103-162637_My Files.jpg"  # Your image path
cache_manager.cache_image(local_image_path)

# Clear old cache files (e.g., older than 1 day)
expiration_time_in_seconds = 60 * 60 * 24  # 1 day
cache_manager.clear_old_cache(expiration_time_in_seconds)