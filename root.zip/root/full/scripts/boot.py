import os
import subprocess
import logging
from datetime import datetime

# Set up logging to track the execution
log_file = "/storage/emulated/0/android/media/root/log/boot_log.txt"
logging.basicConfig(filename=log_file, level=logging.INFO)

def log_action(message):
    logging.info(message)

# Log the start of the script
log_action(f"Boot script started at {datetime.now()}")

# Directory containing root files
root_dir = "/storage/emulated/0/android/media/root/"

# Ensure the directory exists
if not os.path.exists(root_dir):
    log_action(f"Directory {root_dir} does not exist. Exiting script.")
    exit(1)

# Loop through the files and execute them if they are executable
for file_name in os.listdir(root_dir):
    file_path = os.path.join(root_dir, file_name)
    if os.path.isfile(file_path) and os.access(file_path, os.X_OK):  # Check if executable
        try:
            log_action(f"Executing {file_path}")
            subprocess.run([file_path], check=True)  # Run the file
            log_action(f"{file_path} executed successfully")
        except subprocess.CalledProcessError as e:
            log_action(f"Error executing {file_path}: {str(e)}")
    else:
        log_action(f"Skipping non-executable file: {file_path}")

# Log the end of the script
log_action(f"Boot script completed at {datetime.now()}")
