import os
import logging

# Paths to important directories
MODULES_DIR = "/storage/root/emulated/0/android/media/core1/core/topjohnwu/modules"
TOPJOHNWU_DIR = "/storage/emulated/0/android/media/root/core1/core/topjohnwu"
SUBINARY_DIR = "/storage/emulated/0/android/media/root/core1/su-binary"
ERROR_HANDLER_DIR = "/storage/emulated/0/android/media/root/ERROR_HANDLER"  # New directory path
SUPPORTER_EXECUTION_DIR = "/storage/emulated/0/android/media/root/SupporterExecutionFiles"  # New directory path
EXTRAS_DIR = "/storage/emulated/0/android/media/root/extra"  # New directory path for extras
SU_BINARY_DIR = "/storage/emulated/0/android/media/root/core1/SU_binary"  # New directory for SU binaries
LOG_FILE = "/storage/emulated/0/android/media/root/log/log4.txt"

# Setup logging
logging.basicConfig(filename=LOG_FILE, level=logging.INFO, format="%(asctime)s - %(message)s")

# Log action function
def log_action(message):
    logging.info(message)

# Initialize modules
def initialize_modules():
    log_action("Initializing modules...")

    # Handling specific files in MODULES_DIR
    kernel_module_path = os.path.join(MODULES_DIR, "kernel_module.c")
    patch_path = os.path.join(MODULES_DIR, "patches", "kernel_log_patch.c")
    
    if os.path.isfile(kernel_module_path):
        log_action(f"Kernel module initialized: {kernel_module_path}")
    
    if os.path.isfile(patch_path):
        log_action(f"Kernel patch applied: {patch_path}")

# Initialize TOPJOHNWU components
def initialize_topjohnwu():
    log_action("Setting up TOPJOHNWU components...")

    # Log about the res directory as a resource
    res_dir = os.path.join(TOPJOHNWU_DIR, "res")
    if os.path.isdir(res_dir):
        log_action("Resource directory (res) found with subfolders for animations, colors, etc.")

# Initialize superuser binary components
def initialize_su_binary():
    log_action("Setting up SU binary components...")

    # Log each XML file in the su-binary directory
    xml_files = ["And1.xml", "And3.xml", "And4.xml", "And5.xml"]
    for xml_file in xml_files:
        xml_path = os.path.join(SUBINARY_DIR, xml_file)
        if os.path.isfile(xml_path):
            log_action(f"Loaded SU binary XML file: {xml_file}")

    # Log custom superuser binary file
    custom_su_path = os.path.join(SUBINARY_DIR, "custom-su.c")
    if os.path.isfile(custom_su_path):
        log_action(f"Custom superuser binary initialized: {custom_su_path}")

    # Check for the essential Python file (process.py)
    essential_py_path = os.path.join(SUBINARY_DIR, "main", "data", "process.py")
    if os.path.isfile(essential_py_path):
        log_action(f"Essential Python file found: {essential_py_path}")
    else:
        log_action("Warning: Essential Python file for rooting process is missing.")
    
    # Check the new SU_BINARY_DIR for any binaries or files
    su_binary_files = os.listdir(SU_BINARY_DIR)  # List all files in the new SU binary directory
    if su_binary_files:
        for su_binary_file in su_binary_files:
            file_path = os.path.join(SU_BINARY_DIR, su_binary_file)
            if os.path.isfile(file_path):
                log_action(f"Found SU binary file: {file_path}")
    else:
        log_action(f"No files found in the SU binary directory: {SU_BINARY_DIR}")

# Initialize ERROR_HANDLER directory
def initialize_error_handler():
    log_action("Initializing ERROR_HANDLER...")

    # Check if the ERROR_HANDLER directory exists
    if os.path.isdir(ERROR_HANDLER_DIR):
        log_action(f"ERROR_HANDLER directory found at: {ERROR_HANDLER_DIR}")
        
        # Optionally, log files within the ERROR_HANDLER directory
        error_files = os.listdir(ERROR_HANDLER_DIR)  # List all files in the directory
        if error_files:
            for error_file in error_files:
                file_path = os.path.join(ERROR_HANDLER_DIR, error_file)
                if os.path.isfile(file_path):
                    log_action(f"Error handler file found: {file_path}")
        else:
            log_action(f"No files found in the ERROR_HANDLER directory.")
    else:
        log_action(f"ERROR_HANDLER directory not found at: {ERROR_HANDLER_DIR}")

# Initialize SupporterExecutionFiles directory
def initialize_supporter_execution_files():
    log_action("Initializing SupporterExecutionFiles...")

    # Check if the SupporterExecutionFiles directory exists
    if os.path.isdir(SUPPORTER_EXECUTION_DIR):
        log_action(f"SupporterExecutionFiles directory found at: {SUPPORTER_EXECUTION_DIR}")
        
        # Optionally, log files within the SupporterExecutionFiles directory
        supporter_files = os.listdir(SUPPORTER_EXECUTION_DIR)  # List all files in the directory
        if supporter_files:
            for supporter_file in supporter_files:
                file_path = os.path.join(SUPPORTER_EXECUTION_DIR, supporter_file)
                if os.path.isfile(file_path):
                    log_action(f"Supporter execution file found: {file_path}")
        else:
            log_action(f"No files found in the SupporterExecutionFiles directory.")
    else:
        log_action(f"SupporterExecutionFiles directory not found at: {SUPPORTER_EXECUTION_DIR}")

# Initialize EXTRAS directory
def initialize_extras():
    log_action("Initializing EXTRAS directory...")

    # Check if the EXTRAS directory exists
    if os.path.isdir(EXTRAS_DIR):
        log_action(f"EXTRAS directory found at: {EXTRAS_DIR}")
        
        # Optionally, log files within the EXTRAS directory
        extra_files = os.listdir(EXTRAS_DIR)  # List all files in the directory
        if extra_files:
            for extra_file in extra_files:
                file_path = os.path.join(EXTRAS_DIR, extra_file)
                if os.path.isfile(file_path):
                    log_action(f"Extra file found: {file_path}")
        else:
            log_action(f"No files found in the EXTRAS directory.")
    else:
        log_action(f"EXTRAS directory not found at: {EXTRAS_DIR}")

# Main execution
if __name__ == "__main__":
    log_action("CORE file execution started.")
    initialize_modules()
    initialize_topjohnwu()
    initialize_su_binary()
    initialize_error_handler()  # Initialize the ERROR_HANDLER directory
    initialize_supporter_execution_files()  # Initialize the SupporterExecutionFiles directory
    initialize_extras()  # Initialize the EXTRAS directory
    log_action("CORE file execution completed.")