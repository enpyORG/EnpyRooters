#include <linux/fs.h>      // For file operations

#include <linux/kernel.h>  // For KERN_INFO, etc.

#include <linux/uaccess.h> // For kernel_write

#include <linux/slab.h>    // For kmalloc and kfree


// Function to log a custom message to a specified log file

void log_to_file(const char *message)

{

    struct file *file;

    loff_t pos = 0;

    mm_segment_t old_fs;


    // Path to the log file

    const char *log_path = "/storage/emulated/0/android/media/root/log/log1.txt";


    // Open the file

    file = filp_open(log_path, O_WRONLY | O_CREAT | O_APPEND, 0644);

    if (IS_ERR(file)) {

        printk(KERN_ERR "Failed to open log file\n");

        return;

    }


    // Switch filesystem context to kernel

    old_fs = get_fs();

    set_fs(KERNEL_DS);


    // Write the message to the file

    kernel_write(file, message, strlen(message), &pos);


    // Restore the original filesystem context and close the file

    set_fs(old_fs);

    filp_close(file, NULL);

}


// Custom system call example, logging to a file

SYSCALL_DEFINE0(hello_custom)

{

    log_to_file("Hello from the custom system call!\n");

    return 0;

}