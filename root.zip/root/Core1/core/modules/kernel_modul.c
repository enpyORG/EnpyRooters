#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/uaccess.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Dariel");
MODULE_DESCRIPTION("A simple kernel logging module");

#define LOG_FILE_PATH "/storage/emulated/0/android/media/root/log/log2.txt"


// Function to log a message to a file

void log_to_file(const char *message)

{

    struct file *file;

    loff_t pos = 0;

    mm_segment_t old_fs;


    // Open the log file

    file = filp_open(LOG_FILE_PATH, O_WRONLY | O_CREAT | O_APPEND, 0644);

    if (IS_ERR(file)) {

        printk(KERN_ERR "Failed to open log file\n");

        return;

    }


    // Switch to kernel's address space

    old_fs = get_fs();

    set_fs(KERNEL_DS);


    // Write the message to the file

    kernel_write(file, message, strlen(message), &pos);


    // Restore the original address space and close the file

    set_fs(old_fs);

    filp_close(file, NULL);

}


// Module entry point

static int __init my_module_init(void)

{

    log_to_file("Kernel module loaded.\n");

    printk(KERN_INFO "Kernel module loaded.\n");

    return 0; // Return 0 indicates successful loading

}


// Module exit point

static void __exit my_module_exit(void)

{

    log_to_file("Kernel module unloaded.\n");

    printk(KERN_INFO "Kernel module unloaded.\n");

}


// Specify the entry and exit points of the module

module_init(my_module_init); 

module_exit(my_module_exit);