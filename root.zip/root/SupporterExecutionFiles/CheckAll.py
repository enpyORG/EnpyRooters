#!/usr/bin/env python3

import os
import subprocess
import logging

# Define the base path
base_path = "/storage/emulated/0/android/media/root/"

# Define the subdirectories for each category
core1_dictionary_subdir = "core1-dictionary"
supporter_execution_subdir = "SupporterExecutionFiles"
boot_images_subdir = "boot images"
extras_subdir = "extras"
error_handler_subdir = "error_handler"
zips_subdir = "zip’s"
main_subdir = "main"

# Path to shutdown.cpp (compiled executable)
shutdown_cpp = "/storage/emulated/0/android/media/root/shutdown_options/shutdown.cpp"

# Log file path
log_file_path = os.path.join(base_path, "log", "log10.txt")

# Set up logging to log to a file
logging.basicConfig(
    filename=log_file_path,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

# Function to check the existence of files or directories and execute shutdown.cpp if any are missing
def check_and_execute_shutdown():
    # Check each individual path by combining the base path with the subdirectory
    if not os.path.exists(os.path.join(base_path, core1_dictionary_subdir)):
        logging.error("core1-dictionary does not exist. Executing shutdown.cpp.")
        execute_shutdown()
        return

    if not os.path.exists(os.path.join(base_path, supporter_execution_subdir)):
        logging.error("Supporter execution files do not exist. Executing shutdown.cpp.")
        execute_shutdown()
        return

    if not os.path.exists(os.path.join(base_path, boot_images_subdir)):
        logging.error("Boot images do not exist. Executing shutdown.cpp.")
        execute_shutdown()
        return

    if not check_extras():
        logging.error("Extras or extended superuser binaries do not exist. Executing shutdown.cpp.")
        execute_shutdown()
        return

    if not os.path.exists(os.path.join(base_path, error_handler_subdir)):
        logging.error("Error handler does not exist. Executing shutdown.cpp.")
        execute_shutdown()
        return

    if not os.path.exists(os.path.join(base_path, zips_subdir)):
        logging.error("Zips do not exist. Executing shutdown.cpp.")
        execute_shutdown()
        return

    if not os.path.exists(os.path.join(base_path, main_subdir)):
        logging.error("Main does not exist. Executing shutdown.cpp.")
        execute_shutdown()
        return

    # If all files exist
    logging.info("All required files exist. Proceeding with the next operations.")

# Function to check if the Extras directory exists and contains the extended binaries
def check_extras():
    extras_path = os.path.join(base_path, extras_subdir)

    if not os.path.exists(extras_path):
        logging.error(f"{extras_subdir} does not exist.")
        return False

    # Check for extended binaries or specific files in the extras directory
    extended_binaries = ["topjohnwu"]  # Example binary names, add "topjohnwu" here
    for binary in extended_binaries:
        binary_path = os.path.join(extras_path, binary)

        if not os.path.exists(binary_path):
            logging.error(f"Extended binary {binary} is missing from {extras_subdir}.")
            return False

    return True

# Function to execute the shutdown.cpp (assuming it's a C++ program compiled into an executable)
def execute_shutdown():
    # Run the shutdown.cpp executable or shutdown command
    try:
        subprocess.run([shutdown_cpp], check=True)
        logging.info("Shutdown executed successfully.")
    except subprocess.CalledProcessError as e:
        logging.error(f"Error executing shutdown: {e}")

# Call the function to check and execute shutdown if needed
if __name__ == "__main__":
    check_and_execute_shutdown()